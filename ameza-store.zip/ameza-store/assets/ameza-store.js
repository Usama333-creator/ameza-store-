(function(){if(window.__am)return;window.__am=1;
var $=function(s,r){return[].slice.call((r||document).querySelectorAll(s))};
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12});
function reveal(){$('[data-reveal]:not(.in)').forEach(function(e){io.observe(e)})}
function p2(x){return(x<10?'0':'')+x}
function cd(){$('[data-countdown]').forEach(function(el){var end=Date.parse(el.dataset.end),now=Date.now();if(!(end>now)){var d=new Date();d.setHours(23,59,59,999);end=d.getTime()}
var s=Math.max(0,Math.floor((end-now)/1000)),v=[Math.floor(s/86400),Math.floor(s%86400/3600),Math.floor(s%3600/60),s%60];
el.innerHTML=v.map(function(x,i){return'<b>'+p2(x)+'</b>'+(i<3?'<i>:</i>':'')}).join('')})}
document.addEventListener('click',function(e){var c=e.target.closest('[data-copy]');if(!c)return;try{navigator.clipboard.writeText(c.dataset.copy)}catch(x){}var o=c.textContent;c.textContent='Copied ✓';setTimeout(function(){c.textContent=o},1600)});
var ct,demo=0;
function showCart(total,count){$('[data-am-count]').forEach(function(e){e.textContent=count;e.style.display=count?'grid':'none'});
var ex=$('[data-am-proof]')[0],th=Number(ex&&ex.dataset.free||5000);if(!ct){ct=document.createElement('div');ct.className='am-ct';document.body.appendChild(ct)}
var rem=Math.max(0,th-total),pct=Math.min(100,total/th*100);
ct.innerHTML='<b>✓ Added to cart</b> · <a href="/cart">View cart</a><div style="margin-top:6px">'+(rem?'Add <b>Rs '+Math.round(rem).toLocaleString()+'</b> more for <b>FREE delivery</b> 🚚':'🎉 You unlocked <b>FREE delivery</b>!')+'</div><div class="am-bar"><u></u></div>';
ct.classList.add('on');setTimeout(function(){ct.querySelector('u').style.width=pct+'%'},60);clearTimeout(ct._t);ct._t=setTimeout(function(){ct.classList.remove('on')},5200)}
document.addEventListener('submit',function(e){var f=e.target.closest('[data-am-add]');if(!f)return;e.preventDefault();
if(!window.Shopify){demo+=Number(f.dataset.price||0);showCart(demo,Math.max(1,Math.round(demo/2000)));return}
fetch('/cart/add.js',{method:'POST',body:new FormData(f),headers:{Accept:'application/json'}}).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(){return fetch('/cart.js')}).then(function(r){return r.json()}).then(function(c){showCart(c.total_price/100,c.item_count)}).catch(function(){f.submit()})});
function proof(){var el=$('[data-am-proof]')[0];if(!el)return;var L=(el.dataset.list||'').split(/\n|;/).filter(Boolean).map(function(x){return x.split('|')});if(!L.length)return;
var t=document.createElement('div');t.className='am-toast';document.body.appendChild(t);var i=0;
function go(){var a=L[i++%L.length],m=2+Math.floor(Math.random()*40);t.innerHTML='<i>🛍️</i><div><b>'+a[0]+'</b> from '+a[1]+'<br>bought <b>'+a[2]+'</b> · '+m+' min ago</div>';t.classList.add('on');setTimeout(function(){t.classList.remove('on')},5000)}
setTimeout(function(){go();setInterval(go,16000)},6000)}
var sb=$('.am-sticky')[0];function sc(){if(!sb)return;var h=$('.ps')[0];sb.classList.toggle('on',h?h.getBoundingClientRect().bottom<innerHeight*.6:scrollY>innerHeight*.8)}
addEventListener('scroll',sc,{passive:true});
function boot(){reveal();cd();proof();sc()}
setInterval(cd,1000);document.addEventListener('shopify:section:load',reveal);
if(document.readyState!=='loading')boot();else document.addEventListener('DOMContentLoaded',boot);
})();
